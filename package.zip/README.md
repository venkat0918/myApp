# MyApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.2.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).



1. bugs faces and solution to bug;
2. create and edit work for user and the user can see and help to other people ny tacking their     tasks.
3. if admin assign new task and the user imadiatly get the mail to user.
4. user can chat to anothe user for help.
5. sign in with google or fb.
6. sign up send otp for mobile number verification.


smsession 
=============

SM_SESSION is a system cookie used by Siteminder. You shouldn't/mustn't mess with it.

If your application is Siteminder-enabled, Siteminder will take care of the authentication process of the users.
Once the user is authenticated by Siteminder, the Siteminder agent on your application will add specific HTTP headers (notably SM_USER) that will contain information about the user.
You just have to fetch those informations from the request.


2.forkjoin
3.flatmap
4.SSO
5.array.push.apply
6.gettes and setters in js
7.locations
maps and rootes

lifecycle hooks and appinitializer



https://www.npmjs.com/package/currency-formatter

important 
============
1. use firebase databse 
2. crud operation in FDB
3. image upload in FDB and retrive uploaded image 
4. push notification with Firebase
5. Crop image in angular 6
6. idel logout 10 mins