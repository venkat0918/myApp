import { Component } from '@angular/core';

function particale(){
  x: 100;
  y: 22;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myApp';




}
