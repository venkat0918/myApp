import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-user-details',
  templateUrl: './edit-user-details.component.html',
  styleUrls: ['./edit-user-details.component.css']
})
export class EditUserDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
